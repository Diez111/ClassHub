<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>El pepe</title>
</head>
<body>
	<div>
		<h2>Hola <?php echo "$nombre" ?></h2>
	</div>
	<a href="/mvc/home/salir">Salir</a>
</body>
</html>
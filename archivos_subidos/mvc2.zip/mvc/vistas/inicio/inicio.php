<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php require 'vistas/includes/scripts.php'; ?>
	<title>ClassHub</title>
</head>
<body>
	<?php require 'vistas/includes/header.php'; ?>
	<?php require 'vistas/includes/nav.php'; ?>
	<?php require 'vistas/includes/footer.php'; ?>
</body>
</html>

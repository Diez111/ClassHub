<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "vistas/includes/scripts.php"; ?>
	  <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" /><!-- INCLUYE AL BOSSTRAP ALA WEB -->
    <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Include all compiled plugins (below), or include individual files as needed -->      
<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
	<title>ClassHub</title>
</head>
<?php include "vistas/includes/header.php"; ?>
	<?php include "vistas/includes/nav.php"; ?>
<br><br><br><br><br>
<body class="is-preload">
<section id="container">
<div style="margin:auto;width:90%;height:500px;box-shadow:2px 1px 2px 2px #CCCCCC;text-align:left">
<div style="margin-left:20%;padding-top:5%">

<p><a href="/mvc/examen_crear_tema"><font size=6>Añadir tema</font></a></p>
<p><a href="/mvc/examen_crear_prueba"><font size=6>Agregar prueba</font></a></p>
<p><a href="/mvc/examen_crear_pregunta"><font size=6>Agregar pregunta</font> </a></p>
<p align="center" class="head1">&nbsp;</p>
</div>
</div>
	</section>
	<?php include "vistas/includes/footer.php"; ?>
</body>
</html>

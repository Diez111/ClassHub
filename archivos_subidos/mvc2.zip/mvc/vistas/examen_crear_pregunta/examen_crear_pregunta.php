<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php require "vistas/includes/scripts.php"; ?>
	<title>Crear Prueba</title>
</head>
<body>
	<?php require "vistas/includes/header.php"; ?>
	<?php require "vistas/includes/nav.php"; ?>

	<section id="container">
	
	<br><br><br><br>

	<div class="form_register">
		<form method="post" action="<?= FOLDER_PATH . "/examen_crear_pregunta/agregar_pregunta" ?>">
<header>
		<header class="header">
			<div class="container">
			<div class="btn-menu">
				<label for="btn-menu">☰</label>
				</div>
					<nav class="menu">
						<a href="#">Desarroladores</a>
						<a href="https://github.com/Diez111/ClassHub">GitHub</a>
						<a href="inicio/salir">Salir</a>
						<a class="user"> <?php echo "{$nombre} - {$rol}" ?> </a>
					</nav>
			</div>
</header>
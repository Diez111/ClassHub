<footer>
 <!-- Este será nuestro pie de página -->
    </footer>

	
	<link rel="stylesheet" type="text/css" href="/mvc/vistas/includes/css/POSTLOGIN.css">
	<script type="text/javascript" src="/mvc/vistas/includes/js/panCARGA.js"></script>
	<link rel="stylesheet" href="/mvc/vistas/includes/css/tarea.scss">
	<link rel="stylesheet" href="/mvc/vistas/includes/css/calendario.css">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum scale=1.0/">
    
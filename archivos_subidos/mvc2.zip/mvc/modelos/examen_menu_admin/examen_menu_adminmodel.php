<?php 
 class examen_menu_adminmodel extends model
{
public  function __construct()
{
parent::__construct();
}
}
?>
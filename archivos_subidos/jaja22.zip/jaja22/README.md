# ClassHub

Usuarios:

Usuario admin:diez
contraseña: 123456

Usuario de alumno: alumno 
contraseña:123456

Usuario de profesor: Profesor
contraseña: 123456

Funciones:login con roles que le permite al admin crear,modificar y edita los roles de los usuarios.

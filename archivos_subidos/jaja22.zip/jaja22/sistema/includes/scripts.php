	
	<link rel="stylesheet" type="text/css" href="../includes/css/POSTLOGIN.css">
	<script type="text/javascript" src="../includes/js/panCARGA.js"></script>
	<link rel="stylesheet" href="../includes/css/tarea.css">
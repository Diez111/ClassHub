<?php
/*esto es un identificador de fecha que incluye el dia y mes en el que esta el usuario PERO NO FUNCIONA BIEN EL DIA */



/*
	function fechaC(){
		$mes = array("","Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");

		return date('d')." de ". $mes[date('n')] . " de " . date('Y');
	}

*/
 ?>

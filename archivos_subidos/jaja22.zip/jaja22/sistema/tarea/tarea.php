<?php include 'conexion.php';?>


<?php
	session_start();
 ?>



<!DOCTYPE html>
<html lang="en">
<header>
	<meta charset="UTF-8">
	<title>ClassHub</title>
    
    <?php include "../includes/scripts.php"; ?>


</head>
<body>
<?php include "../includes/header.php"; ?>
	<section id="container">




	</section>


    <?php
		if($_SESSION['rol'] == 1 ||  $_SESSION['rol'] == 2 ){
	 ?>
 <br></br><br></br><br></br>

<?php include "iconos.php"; ?>
</head>



<main class="container">
    <div class="row">
        <div class="col-4">
            <form action="saveTask.php" method="post">
                <div class="form-group card border-primary">
                    <div class="card-body">
                        <p>
                            <label for="">ClassHub</label>
                            <input type="text" name="title" id="title" class="form-control">
                        </p>
                        <p>
                            <label for="">Description</label>                                
                            <textarea name="description" id="description" rows="4" class="form-control"></textarea>
                        </p>
                       


                        <?php
					include "../../conexion.php";
					$query_curso = mysqli_query($conection,"SELECT * FROM curso");
					$result_curso = mysqli_num_rows($query_curso);
				 ?>



<a>Curso</a>

                        <select name="curso" id="curso">
					<?php
						if($result_curso > 0)
						{
							while ($curso = mysqli_fetch_array($query_curso)) {
					?>
							<option value="<?php echo $curso["idcurso"]; ?>"><?php echo $curso["curso"] ?></option>
					<?php
								# code...
							}

						}
					 ?>
				</select>


                        <p class="center-content">
        <input type="submit" class="btn btn-green" value="Save" name="save">
    </p>




                    </div>
                </div>
            </form>
        </div>


<br></br><br></br>





          
                <table class="table border">
                    <thead>
                        <tr>
                            <th>Titulo</th>
                            <th>Descripcion</th>
                            <th>Curso</th>
                            <th>Fecha de creacion</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>                        
                        <?php 
                            $sql = "select id, title, description, curso,  create_at from task";
                            $result = $conection->query($sql);
                            while($row = $result->fetch_assoc()) {                                
                        ?>
                        <tr>
                            <td><?php echo $row["title"]?></td>
                            <td><?php echo $row["description"]?></td>
                            <td><?php echo $row["curso"]?></td>
                            <td><?php echo $row["create_at"]?></td>
                            <td>
                                <a href="editTask.php?id=<?php echo $row["id"]?>" class="btn btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="deleteTask.php?id=<?php echo $row['id'] ?>" class="btn btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>                        
                        <?php                                 
                            }                                                                 
                        ?>                        
                    </tbody>
                </table>
            </div>
  
    
</main>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


<?php include "../includes/footer.php"; ?>
	<?php } 	?>










 
    <?php
		if($_SESSION['rol'] == 3){
	 ?>
 <br></br><br></br><br></br>

<?php include "iconos.php"; ?>
</head>






<br>

<a class="user"><?php echo $_SESSION['user'].' -'.$_SESSION['curso']; ?> </a>






          
          
<table class="table border">
                    <thead>
                        <tr>
                            <th>Titulo</th>
                            <th>Descripcion</th>
                            <th>Curso</th>
                            <th>Fecha de creacion</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>                        
                        <?php 

        

                            $sql = "select id, title, description, curso,  create_at from task";
                            $result = $conection->query($sql);
                            while($row = $result->fetch_assoc()) {                                
                        ?>

                        
                        <tr>
                            <td><?php echo $row["title"]?></td>
                            <td><?php echo $row["description"]?></td>
                            <td><?php echo $row["curso"]?></td>
                            <td><?php echo $row["create_at"]?></td>
                            <td>
                                <a href="editTask.php?id=<?php echo $row["id"]?>" class="btn btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="deleteTask.php?id=<?php echo $row['id'] ?>" class="btn btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>                        
                        <?php                                 
                            }                                                                 
                        ?>                        
                    </tbody>
                </table>
            </div>



<center> 
            <form action="buscar_usuario.php" method="get" class="form_search">
		<input type="text" name="busqueda" id="busqueda" placeholder="Buscar">
		<input type="submit" value="Buscar" class="btn_search">
	</form>
    </center>    
    
</main>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


<?php include "../includes/footer.php"; ?>
	<?php } 	?>








   
</body>
</html>

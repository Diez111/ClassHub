<?php 
include 'conexion.php';
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = 'delete from task where id =' . $id;    
    $conection->query($sql);    
}
header('Location: tarea.php');
?>


<?php
    include 'conexion.php';
    
    if(isset($_POST['save']))
    {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $cursotarea = $_POST['curso'];     
        $sql = "insert into task (title, description, curso) values ('". $title ."', '" . $description . "', '" . $cursotarea . "')";            
        $conection->query($sql);
    } 
    header('Location: tarea.php');
?>
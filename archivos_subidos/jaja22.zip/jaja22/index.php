<?php

$alert = '';
session_start();
if(!empty($_SESSION['active']))   //Verificamos si la sesion esta activa
{
	header('location: sistema/inicio/index.php');		//Si hay una sesion activa pasamos a la siguiente pagina
}else{  //sino seguimos con la comparacion

	if(!empty($_POST)) 		//verificamos si tenemos algun dato, si la variable esta vacia pasa al siguiente if
	{
		if(empty($_POST['usuario']) || empty($_POST['clave'])) //verificamos si los espacios de usuario y clave tienen algun dato
		{
			$alert = 'Ingrese su usuario y su clave';   //si el usuario no agrego ningun dato muestra esta alerta
		}else{ //en caso contrario

			require_once "conexion.php"; //se conecta a la base de datos para verificar la lista de usuarios

			$user = mysqli_real_escape_string($conection,$_POST['usuario']);   //verificamos que el usuario existe
			$pass = md5(mysqli_real_escape_string($conection,$_POST['clave'])); //verificamos que la contraseña existe

			$query = mysqli_query($conection,"SELECT * FROM usuario WHERE usuario= '$user' AND clave = '$pass'"); //hace la consulta de los datos
			mysqli_close($conection);
			$result = mysqli_num_rows($query); //muestra el resultado de la consulta

			if($result > 0) //si la consulta se realiza correctamente
			{
				$data = mysqli_fetch_array($query);			//se crea un arreglo donde se comparan los datos
				$_SESSION['active'] = true;
				$_SESSION['idUser'] = $data['idusuario'];
				$_SESSION['nombre'] = $data['nombre'];
				$_SESSION['email']  = $data['email'];
				$_SESSION['user']   = $data['usuario'];
				$_SESSION['curso']  = $data['curso'];
				$_SESSION['rol']    = $data['rol'];
				

				header('location: sistema/inicio/index.php');	 //si todo se cumple y es igual paso a la siguiente pagina
			}else{
				$alert = 'El usuario o la clave son incorrectos';  //sino muestra esta alerta
				session_destroy(); //y destruye la secion por seguridad
			}


		}

	}
}
 ?>
<!DOCTYPE html>
<html lang="en">  <! ––El idioma de la pagina por defecto el IDE lo pone en ingles ––>
<head>
	<meta charset="UTF-8"> <! ––usamos los caracteres del español ––>
	<title>Login | Sistema Facturación</title>  <! –– El titulo de la pestaña ––>
	<link rel="stylesheet" type="text/css" href="style.css"> <! –– llamamos al estilo ––>
</head>
<body>
	<section id="container"> <! –– juntamos todos los datos de abajo en un contenedor ––>

		<form action="" method="post"> <! –– Usamos el comando POST para mandar los datos que ingrese el usuario ––>

			<h3>Instituto Madero</h3>
			<img src="img/login1.png" alt="Login">

			<input type="text" name="usuario" placeholder="Usuario"> <! –– El texto ingresado en en esta opcion se puede llamar en php para usarla como string––>
			<input type="password" name="clave" placeholder="Contraseña"> <! –– El texto ingresado en en esta opcion se puede llamar en php para usarla como string––>
			<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div> <! –– Muestra las alertas que mande php ––>
			<input type="submit" value="INICIAR">

		</form>

	</section>
</body>
</html>

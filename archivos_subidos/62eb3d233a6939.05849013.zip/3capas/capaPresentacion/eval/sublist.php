
<?php
    session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "../includes/scripts.php"; ?>
        <!-- Bootstrap -->
   <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" /><!-- INCLUYE AL BOSSTRAP ALA WEB -->
    <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
   <script src="http://localhost/exam/exam/datespicker/css/datepicker.css"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->      
<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
<script type="text/javascript"></script>
    <title>ClassHub</title>
</head>
<body class="is-preload">
    <?php include "../includes/header.php"; ?>
    <section id="container">

        <br><br><br><br><br><br><br><br><br>
<?php
include("header.php");
include("database.php");
echo "<center><h2 class=head1> Seleccione Asunto para dar cuestionario</h2></center>";

      $sql = "SELECT * FROM mst_subject";
    $rs=mysqli_query($con,$sql);
  $row = mysqli_fetch_array($rs,MYSQLI_ASSOC);
    $count = mysqli_num_rows($rs);

echo "<table align=center class='table'>";
while($row=mysqli_fetch_row($rs))
{
    echo "<tr class='success'><td align=center class='text-danger'><a  href=showtest.php?subid=$row[0]><font class='text-warning' size=6>$row[1]</font></a>";
}
echo "</table>";
?>
    </section>
    <?php include "../includes/footer.php"; ?>
</body>
</html>





<?php
	session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "../../includes/scripts.php"; ?>
	  <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" /><!-- INCLUYE AL BOSSTRAP ALA WEB -->
    <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
   <script src="http://localhost/exam/exam/datespicker/css/datepicker.css"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->      
<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
<script type="text/javascript"></script>
	<title>ClassHub</title>
</head>
<body class="is-preload">
	<?php include "../../includes/header.php"; ?>
	<section id="container">
<?php
include("header.php");
extract($_POST);
if(isset($submit))
{
	include("../database.php");
	
      $sql = "SELECT * FROM usuario WHERE nombre='$loginid' and ''='$pass'";
	$rs=mysqli_query($con,$sql);
  $row = mysqli_fetch_array($rs,MYSQLI_ASSOC);
    $count = mysqli_num_rows($rs);
	if($count<1)
	{
				echo "<BR><BR><BR><BR><div class=head1> Usuario o contraseña invalido<div>";
		exit;
	}
$_SESSION['alogin']="true";
	
}
else if(!isset($_SESSION[alogin]))
{
	echo "<BR><BR><BR><BR><div class=head1>Usted no se ha identificado<br> Por favor <a href=index.php>Login</a><div>";
		exit;
}
?>

<p class="head1">Bienvenido al área administrativa </p>
<div style="margin:auto;width:90%;height:500px;box-shadow:2px 1px 2px 2px #CCCCCC;text-align:left">
<div style="margin-left:20%;padding-top:5%">

<p class="style7"><a href="subadd.php"><font  class='text-danger' size=6>Añadir tema</font></a></p>
<p class="style7"><a href="testadd.php"><font  class='text-danger' size=6>Agregar prueba</font></a></p>
<p class="style7"><a href="questionadd.php"><font  class='text-danger' size=6>Agregar pregunta</font> </a></p>
<p align="center" class="head1">&nbsp;</p>
</div>
</div>
	</section>
	<?php include "../../includes/footer.php"; ?>
</body>
</html>





<?php
    session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <?php include "../includes/scripts.php"; ?>
        <!-- Bootstrap -->
   <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" /><!-- INCLUYE AL BOSSTRAP ALA WEB -->
    <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
   <script src="http://localhost/exam/exam/datespicker/css/datepicker.css"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->      
<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
<script type="text/javascript"></script>
    <title>ClassHub</title>
</head>
<body class="is-preload">
    <?php include "../includes/header.php"; ?>
    <section id="container">

        <br><br><br><br><br><br><br><br><br>
<?php
include("header.php");
include("database.php");
extract($_GET);
$rs1=mysqli_query($con,"select * from mst_subject where sub_id=$subid");
$row1=mysqli_fetch_array($rs1);
echo "<center><h1 align=center><font color=blue> $row1[1]</font></h1></center>";
$rs=mysqli_query($con,"select * from mst_test where sub_id=$subid");
if(mysqli_num_rows($rs)<1)
{
    echo "<center><br><br><h2 class=head1>Evaluaciones del tema</h2></center>";
    exit;
}
echo "<center><h2 class=head1>Evaluaciones del tema</h2>";
echo "<table align=center class='table'></center>";

while($row=mysqli_fetch_row($rs))
{
    echo "<tr class='success'><td class='text-danger' align=center ><a href=quiz.php?testid=$row[0]&subid=$subid><font  class='text-warning' size=6>$row[2]</font></a>";
}
echo "</table>";
?>
    </section>
    <?php include "../includes/footer.php"; ?>
</body>
</html>





<?php
  session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">



    <link href="http://localhost/exam/exam/css/style.css" rel="stylesheet" type="text/css" />
    <!-- Bootstrap -->
   <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" /><!-- INCLUYE AL BOSSTRAP ALA WEB -->
    <link href="http://localhost/exam/exam/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
   <script src="http://localhost/exam/exam/datespicker/css/datepicker.css"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->      
<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
<script type="text/javascript"></script>
  <?php include "../includes/scripts.php"; ?>
  <title>ClassHub</title>
</head>
<body class="is-preload">


  <?php include "../includes/header.php"; ?>
  <section id="container">

  </section>

<?php
include("header.php");
include("database.php");
extract($_POST);

if(isset($submit))
{


      $sql = "SELECT * FROM usuario WHERE nombre='$loginid' and ''='$pass'";
  $rs=mysqli_query($con,$sql);
  $row = mysqli_fetch_array($rs,MYSQLI_ASSOC);
    $count = mysqli_num_rows($rs);
  if($count<1)
  {
    $found="N";
  }
  else
  {
    $_SESSION[login]=$loginid;
  }
}
if (isset($_SESSION[login]))
{
echo "<br><br><br><br><br>


<h1 class='style8' align=center>Bien venido al examen en línea</h1>";



    echo 

    '
    <table width="28%"  border="0" align="center">
  <tr>
    <td  width="7%" height="65" valign="bottom"><img src="image/HLPBUTT2.JPG" width="50" height="50" align="middle"></td>
    <td width="93%" valign="bottom" bordercolor="#0000FF"> <a href="sublist.php" class="alert alert-danger">Sujeto para el cuestionario </a></td>
  </tr>
  <tr>
    <td  width="7%" height="65" valign="bottom"><img src="image/DEGREE.JPG" width="43" height="43" align="absmiddle"></td>
    <td width="93%" valign="bottom" bordercolor="#0000FF"> <a href="result.php" class="alert alert-danger">Resultado </a></td>
  </tr>


    ';
   
    exit;
    

}


?>
<br></br><br></br><br></br>
 <center>
    <td valign="top"><form name="form1" method="post" action="">
    
        <tr>
          <td><span class="style2">Nombre</span></td><td><input name="loginid" type="text" id="loginid2"></td>
        </tr>
              
        
          <td colspan="2"><span class="errors">
            <?php
      if(isset($found))
      {
        echo "Usuario o contraseña invalido";
      }
      ?>
          </span></td>
          </tr>
        <tr>
          <td colspan=2 align=center class="errors">
      <input name="submit" type="submit" id="submit" value="Login">     </td>
        </tr>
    
      </table>
      
    </form></td>
  </tr>
</center>

  <?php include "../includes/footer.php"; ?>




</body>
</html>




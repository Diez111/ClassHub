<?php
error_reporting(1);

$con = mysqli_connect("localhost","root","","classhub") or die(mysql_error());



?>

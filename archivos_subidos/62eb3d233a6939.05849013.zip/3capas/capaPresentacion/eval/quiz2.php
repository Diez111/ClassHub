<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style9 {
	color: #000099;
	font-weight: bold;
}
.style10 {
	color: #330066;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
-->
</style>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="image/topbkg.jpg">
  <tr>
    <td width="90%" valign="top">
<!--You can modify the text, color, size, number of loops and more on the flash header by editing the text file (fence.txt) included in the zip file.-->
<div align="left"><object classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000
codebase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,2,0
width=500
height=68>
<param name=movie value=image/fence.swf>
<param name=quality value=high>
<param name=BGCOLOR value=#000000>
<param name=SCALE value=showall>
<param name=wmode value=transparent> 
<embed src=image/fence.swf
quality=high
pluginspage=http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash type=application/x-shockwave-flash
width=500
height=68
bgcolor=#000000
scale= showall>
</embed>
</object></div></td>
    <td width="10%">
     <img border="0" src="image/topright.jpg" width="203" height="68" align="right"></td>
  </tr>
</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#000000" background="img/blackbar.jpg">
  <tr>
    <td width="100%"><img border="0" src="image/blackbar.jpg" width="89" height="15"></td>
  </tr>
</table>
<table width="100%"  border="0">
  <tr>
    <td width="89%"><span class="style9">Evaluacion</span></td>
    <td width="11%"><span class="style10">Signout</span></td>
  </tr>
</table>
<strong>PHP Test
</strong>
<table width="304"  border="0" align="center">
  <tr>
    <td width="298"><div align="left"><strong> Q-1</strong> <strong>: Lo que no es elemento Php?</strong></div></td>
  </tr>
  <tr>
    <td>
      <div align="left">
        <input type=radio name=ans value=1>
    <strong> Enviar</strong></div></td>
  </tr>
  <tr>
    <td>
      <div align="left">
        <input type=radio name=ans value=2>
    <strong> Obtener    </strong></div></td>
  </tr>
  <tr>
    <td>
      <div align="left">
        <input type=radio name=ans value=3>
    <strong>Sesión</strong></div></td>
  </tr>
  <tr>
    <td>
      <div align="left">
        <input type=radio name=ans value=4>
    <strong> Cookie    </strong></div></td>
  </tr>
  <tr>
    <td>
      <div align="center">
        <input type=submit name=submit value='Próxima pregunta'>
        </div></td>
  </tr>
</table>
</body>
</html>

<?php
  session_start();
  require("database.php");
error_reporting(1);
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <?php include "../includes/scripts.php"; ?>
  <title>ClassHub</title>
</head>
<body class="is-preload">
  <?php include "../includes/header.php"; ?>
  <section id="container">
<link href="../eval/quiz.css" rel="stylesheet" type="text/css">
<?php

extract($_POST);

echo "<BR>";
if (!isset($_SESSION['alogin']))
{
  echo "<br><h2><div  class=head1>No has iniciado sesión. Ingresa para acceder a esta página.</div></h2>";
  echo "<a href=index.php><h3 align=center>Haga clic aquí para iniciar sesión</h3></a>";
  exit();
}
echo "<br><br><br>";
echo "<BR><center><h3 class=head1>Asunto Agregar</h3></center>";


if($submit=='submit' || strlen($subname)>0 )
{


      $sql = "SELECT * FROM mst_subject WHERE sub_name='$subname'";
  $rs=mysqli_query($con,$sql);
  $row = mysqli_fetch_array($rs,MYSQLI_ASSOC);
    $count = mysqli_num_rows($rs);
  if($count>0)
  {
    echo "<br><br><br><div class=head1>El tema ya existe
</div>";
  exit;
  }
$query="insert into mst_subject(sub_name) values ('$subname')";
$rs2=mysqli_query($con,$query)or die("No se pudo realizar la consulta");
echo "<p align=center>Subject  <b> \"$subname \"</b> Agregado exitosamente.</p>";
$submit="";


}
?>
<SCRIPT LANGUAGE="JavaScript">
function check() {
mt=document.form1.subname.value;
if (mt.length<1) {
alert("Por favor ingrese el nombre del tema");
document.form1.subname.focus();
return false;
}
return true;
}
</script>
<form name="form1" method="post" onSubmit="return check();">
  <table width="41%"  border="0" align="center">
    
    <tr>
        <input name="subname" placeholder="ingrese el nombre del tema" type="text" id="subname">
    <tr>
      <td><input type="submit" name="submit" value="Agregar" ></td>
    </tr>
  </table>
</form>
<p>&nbsp; </p>

  </section>
  <?php include "../includes/footer.php"; ?>
</body>
</html>





<?php
  session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <?php include "../includes/scripts.php"; ?>
  <link href="../quiz.css" rel="stylesheet" type="text/css">
  <title>ClassHub</title>
</head>
<body class="is-preload">
  <?php include "../includes/header.php"; ?>
  <section id="container">


<br><br><br><br><br><br>

<form name="form1" method="post" action="login.php">
<table width="90" border="0">
        <a>Nombre del admin</a>

    <td width="49"><input name="loginid" type="text" id="loginid"></td>
  </tr>
  <tr>
    <td class="style2">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
  
    <td><input name="submit" type="submit" id="submit" value="Login"></td>
  </tr>
</table></td>
  </tr>
</table>

</form>

  </section>
  <?php include "../includes/footer.php"; ?>
</body>
</html>




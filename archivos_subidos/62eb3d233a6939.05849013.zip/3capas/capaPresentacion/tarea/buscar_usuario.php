<?php
	session_start();
	include "../../capaBD/conexion.php";

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "../includes/scripts.php"; ?>
	<title>Tipos de usuarios</title>
</head>
<body>
	<?php include "../includes/header.php"; ?>
	<section id="container">
	<?php
		if($_SESSION['rol'] == 3){
	 ?>
 <br></br><br></br><br></br>

<?php include "iconos.php"; ?>
</head>








          
          
<table class="table border">
                    <thead>
                        <tr>
                            <th>Titulo</th>
                            <th>Descripcion</th>
                            <th>Curso</th>
                            <th>Fecha de creacion</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>                        
                        <?php 

        

                            $sql = "select id, title, description, curso,  create_at from task";
                            $result = $conection->query($sql);
                            while($row = $result->fetch_assoc()) {                                
                        ?>

                        
                        <tr>
                            <td><?php echo $row["title"]?></td>
                            <td><?php echo $row["description"]?></td>
                            <td><?php echo $row["curso"]?></td>
                            <td><?php echo $row["create_at"]?></td>
                            <td>
                                <a href="editTask.php?id=<?php echo $row["id"]?>" class="btn btn-success">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="deleteTask.php?id=<?php echo $row['id'] ?>" class="btn btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>                        
                        <?php                                 
                            }                                                                 
                        ?>                        
                    </tbody>
                </table>
            </div>



<center> 
            <form action="buscar_usuario.php" method="get" class="form_search">
		<input type="text" name="busqueda" id="busqueda" placeholder="Buscar">
		<input type="submit" value="Buscar" class="btn_search">
	</form>
    </center>    
    
</main>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>


<?php include "../includes/footer.php"; ?>
	<?php } 	?>


</body>
</html>

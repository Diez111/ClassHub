
<?php
	session_start();
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "../includes/scripts.php"; ?>
	<title>ClassHub</title>
</head>
<body class="is-preload">
	<?php include "../includes/header.php"; ?>
	<section id="container">

	</section>
	<?php include "../includes/footer.php"; ?>
</body>
</html>




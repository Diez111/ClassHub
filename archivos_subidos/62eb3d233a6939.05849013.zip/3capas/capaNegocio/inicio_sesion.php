<?php
$alert = '';
session_start();
if(!empty($_SESSION['active']))   //Verificamos si la sesion esta activa
{
  header('location: capaPresentacion/inicio/index.php');    //Si hay una sesion activa pasamos a la siguiente pagina
}else{  //sino seguimos con la comparacion

  if(!empty($_POST))    //verificamos si tenemos algun dato, si la variable esta vacia pasa al siguiente if
  {
    if(empty($_POST['usuario']) || empty($_POST['clave'])) //verificamos si los espacios de usuario y clave tienen algun dato
    {
      $alert = 'Ingrese su usuario y su clave';   //si el usuario no agrego ningun dato muestra esta alerta
    }else{ //en caso contrario

      include_once "capaBD/conexion.php"; //se conecta a la base de datos para verificar la lista de usuarios
      include_once "capaBD/login.php"; //incluye la libreria para verificar al usuario

      $verificacion = verificacion($conection); //verifica si existe y le pasa los datos
      $result = mysqli_num_rows($verificacion); //muestra el resultado de la consulta

      if($result > 0) //si la consulta se realiza correctamente
      {
        $data = mysqli_fetch_array($verificacion);      //se crea un arreglo donde se comparan los datos
        $_SESSION['active'] = true;
        $_SESSION['idUser'] = $data['idusuario'];
        $_SESSION['nombre'] = $data['nombre'];
        $_SESSION['email']  = $data['email'];
        $_SESSION['user']   = $data['usuario'];
        $_SESSION['curso']  = $data['curso'];
        $_SESSION['rol']    = $data['rol'];


        header('location: capaPresentacion/inicio/index.php');   //si todo se cumple y es igual paso a la siguiente pagina
      } else {
        $alert = 'El usuario o la clave son incorrectos';  //sino muestra esta alerta
        session_destroy(); //y destruye la secion por seguridad
      }
    }
  }
}
?>

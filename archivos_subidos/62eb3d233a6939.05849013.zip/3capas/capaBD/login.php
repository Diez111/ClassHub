<?php
function verificacion(&$conection){
  $user = mysqli_real_escape_string($conection,$_POST['usuario']);   //verificamos que el usuario existe
  $pass = md5(mysqli_real_escape_string($conection,$_POST['clave'])); //verificamos que la contraseña existe

  $query = mysqli_query($conection,"SELECT * FROM usuario WHERE usuario= '$user' AND clave = '$pass'"); //hace la consulta de los datos
  mysqli_close($conection);

  return $query;
}
?>

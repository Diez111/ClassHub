<?php

	session_start();		/*Si la sesion esta iniciada*/
	session_destroy();	/*Se destruye la sesion*/

	header('location: ../index.php');

 ?>
